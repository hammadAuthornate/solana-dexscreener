import { Helius } from "helius-sdk";
export const helius = new Helius("665dedb4-c0a6-4971-ae7d-e668b39d2efd");
